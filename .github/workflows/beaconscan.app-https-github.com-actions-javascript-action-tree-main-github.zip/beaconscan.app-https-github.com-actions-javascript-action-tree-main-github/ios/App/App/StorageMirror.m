//
//  StorageMirror.m
//  App
//
//  Created by Kai Pflaume on 28.04.21.
//

#import <Capacitor/Capacitor.h>

CAP_PLUGIN(StorageMirror, "StorageMirror",
           CAP_PLUGIN_METHOD(reflect, CAPPluginReturnNone);
)
